<?php get_header();?>
<h1>Hola</h1>
<?php get_footer();?>
	