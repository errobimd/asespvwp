<!-- Start: Pie de pagina -->
<footer class="container">
	<div class="row" style="background-color: #774f2f;">
		<div class="col text-center">
			<p>Todos los derechos reservados</p>
		</div>
		<div class="col text-center">
			<p>ASES España</p>
		</div>
	</div>
</footer>
<!-- End: Pie de pagina -->
<?php wp_footer();?>